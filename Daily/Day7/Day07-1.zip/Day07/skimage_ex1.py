import matplotlib.pyplot as plt
from skimage.io import imread
from skimage.filters import sobel

#load the image of buckaroo
buck = imread("buckaroo_crop.png")
print(buck.shape)

edges = sobel(buck)

plt.imshow(edges)
plt.show()
