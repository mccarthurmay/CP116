from sklearn.datasets import load_iris
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score

# load the data
data = load_iris()
print(data)

# unpack the data
X = data["data"]
Y = data["target"]

print(X)
print(Y)

model = MLPClassifier(hidden_layer_sizes=[3], max_iter=1000)
model.fit(X, Y)

Y_predicted = model.predict(X)

print(Y_predicted)
print(Y)

print(accuracy_score(Y, Y_predicted))

#print(model.coef_)




#
