from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# load the data
data = load_iris()
print(data)

# unpack the data
X = data["data"]
Y = data["target"]

print(X)
print(Y)

model = LogisticRegression()
model.fit(X, Y)

Y_predicted = model.predict(X)

print(Y_predicted)
print(Y)

print(accuracy_score(Y, Y_predicted))

print(model.coef_)




#
